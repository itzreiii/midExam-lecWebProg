document.addEventListener('DOMContentLoaded', function () {
    console.log('JavaScript Loaded');
    // Add event listeners and other functionality
});
