<form action="create-event.php" method="POST">
    <input type="text" name="event_name" placeholder="Event Name" required>
    <textarea name="description" placeholder="Event Description"></textarea>
    <button type="submit">Create Event</button>
</form>
