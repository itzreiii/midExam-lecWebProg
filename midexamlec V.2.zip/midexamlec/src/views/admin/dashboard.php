<h1>Admin Dashboard</h1>
<a href="event-form.php">Create New Event</a>
