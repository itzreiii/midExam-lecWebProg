<h1><?= $event['name'] ?></h1>
<p><?= $event['description'] ?></p>
<a href="register.php?event_id=<?= $event['id'] ?>">Register</a>
