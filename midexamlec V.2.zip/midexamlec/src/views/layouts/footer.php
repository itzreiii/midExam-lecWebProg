<footer class="footer">
    <p>&copy; <?= date('Y') ?> Event Registration</p>
</footer>
