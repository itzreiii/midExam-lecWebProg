<?php
// Application Config
define('APP_NAME', 'Event Registration');
define('APP_URL', 'http://localhost/event-registration');
?>
